# Custom Node Module

## This module contains the following:
### Node Script
* Contains a basic Node class
### Stack Script
* Contains a custom Stack class
### LinkedList
* Work in progress since it is not needed at the moment